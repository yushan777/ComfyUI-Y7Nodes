import torch
import torch.nn.functional as F
from comfy_api.latest import io

MAX_RESOLUTION = 16384

FILL_MODES = ["grey", "edge replicate", "mirror", "blurred edge", "noise"]

def snap_to_step(value, step):
    """Round to the nearest multiple of step, ties rounding up."""
    if step <= 1:
        return value
    quotient, remainder = divmod(value, step)
    if remainder * 2 >= step:
        quotient += 1
    return quotient * step


def resolve_padding(left, top, right, bottom, step):
    """Turn the raw widget values into the final padding by snapping each to `step`."""
    return (
        snap_to_step(left, step),
        snap_to_step(top, step),
        snap_to_step(right, step),
        snap_to_step(bottom, step),
    )


def _replicate_index(length, before, after, device):
    """Indices into a row/column of `length` px that clamp to the edge outside it."""
    return torch.arange(-before, length + after, device=device).clamp(0, length - 1)


def _mirror_index(length, before, after, device):
    """Indices into a row/column of `length` px that reflect back inside it."""
    idx = torch.arange(-before, length + after, device=device)
    if length == 1:
        return torch.zeros_like(idx)
    period = 2 * length - 2
    idx = idx.abs() % period
    return torch.where(idx >= length, period - idx, idx)


def _fill_canvas(image, left, top, right, bottom, fill):
    """
    Build the padded canvas and fill the new region according to `fill`.
    The original image is not pasted in yet - the caller does that.
    """
    d1, d2, d3, d4 = image.size()
    new_h, new_w = d2 + top + bottom, d3 + left + right
    # Every fill mode must land on the same device as the incoming image, otherwise
    # the padded image and the mask disagree and downstream nodes blow up.
    device = image.device

    if fill == "grey":
        return torch.ones((d1, new_h, new_w, d4), dtype=torch.float32, device=device) * 0.5

    if fill == "noise":
        mean = image.mean(dim=(1, 2), keepdim=True)
        std = image.std(dim=(1, 2), keepdim=True)
        noise = torch.randn((d1, new_h, new_w, d4), dtype=torch.float32, device=device)
        return (noise * std * 0.5 + mean).clamp(0.0, 1.0)

    index = _mirror_index if fill == "mirror" else _replicate_index
    rows = index(d2, top, bottom, device)
    cols = index(d3, left, right, device)
    canvas = image[:, rows][:, :, cols].float()

    if fill == "blurred edge":
        # Heavy downscale then bilinear back up - a cheap, very soft blur that
        # smears the edge colours outwards instead of leaving hard streaks.
        scale = max(2, max(new_h, new_w) // 48)
        small = F.interpolate(
            canvas.permute(0, 3, 1, 2),
            size=(max(1, new_h // scale), max(1, new_w // scale)),
            mode="area",
        )
        canvas = F.interpolate(
            small, size=(new_h, new_w), mode="bilinear", align_corners=False
        ).permute(0, 2, 3, 1)

    return canvas.contiguous()


def _feather_mask(d2, d3, left, top, right, bottom, feathering, device):
    """
    The soft ramp painted over the original image region, matching the built-in node's
    falloff but computed with tensor ops instead of a per-pixel Python loop.
    """
    t = torch.zeros((d2, d3), dtype=torch.float32, device=device)

    # The built-in silently skips feathering once it no longer fits; clamp instead so
    # a large value still gives the widest ramp the image can hold.
    f = min(feathering, (min(d2, d3) - 1) // 2)
    if f <= 0:
        return t

    ii = torch.arange(d2, dtype=torch.float32, device=device).view(-1, 1).expand(d2, d3)
    jj = torch.arange(d3, dtype=torch.float32, device=device).view(1, -1).expand(d2, d3)

    # A side with no padding contributes no falloff, so it is given a distance
    # large enough to never win the min().
    big_v = torch.full((d2, d3), float(d2), device=device)
    big_h = torch.full((d2, d3), float(d3), device=device)

    dt = ii if top != 0 else big_v
    db = (d2 - ii) if bottom != 0 else big_v
    dl = jj if left != 0 else big_h
    dr = (d3 - jj) if right != 0 else big_h

    d = torch.minimum(torch.minimum(dt, db), torch.minimum(dl, dr))
    v = ((f - d) / f).clamp(min=0.0)
    return v * v


class Y7Nodes_ImagePadForOutpaint(io.ComfyNode):
    """
    Pad an image ready for outpainting.

    A rework of ComfyUI's built-in ImagePadForOutpaint with the fiddly parts smoothed
    out: padding snaps to a chosen step, the new area can be filled with something more
    useful than flat grey, and the feathering is vectorised rather than looping over
    every pixel in Python.
    """

    @classmethod
    def define_schema(cls):
        return io.Schema(
            node_id="Y7Nodes_ImagePadForOutpaint",
            display_name="Y7 Pad Image for Outpainting",
            category="Y7Nodes/Image",
            description="Pad an image ready for outpainting, with the padding snapped to a "
                        "chosen step and a choice of what to fill the new area with.",
            is_output_node=True,
            inputs=[
                io.Image.Input("image"),
                io.Int.Input(
                    "step",
                    default=16,
                    min=1,
                    max=1024,
                    step=1,
                    tooltip="Padding is rounded to a multiple of this number, so the "
                            "final image stays a size the model is happy with. Also "
                            "sets how far the +/- arrows move each side.",
                ),
                io.Combo.Input(
                    "fill",
                    options=FILL_MODES,
                    default="grey",
                    tooltip="What to put in the new area before outpainting. "
                            "grey: flat 50% grey, same as the built-in node. "
                            "edge replicate: smears the outermost pixels outwards. "
                            "mirror: reflects the image back on itself. "
                            "blurred edge: a soft blur of the nearby colours. "
                            "noise: random noise in the image's own colours. "
                            "It all gets painted over anyway, but a plausible starting "
                            "colour usually gives a better outpaint than flat grey.",
                ),
                io.Int.Input(
                    "feathering",
                    default=40,
                    min=0,
                    max=MAX_RESOLUTION,
                    step=1,
                    advanced=True,
                    tooltip="Width in pixels of the soft fade at the join between the "
                            "original image and the new area. 0 gives a hard edge.",
                ),
                io.Int.Input(
                    "left", default=0, min=0, max=MAX_RESOLUTION, step=1,
                    tooltip="Pixels to add to the left edge.",
                ),
                io.Int.Input(
                    "top", default=0, min=0, max=MAX_RESOLUTION, step=1,
                    tooltip="Pixels to add to the top edge.",
                ),
                io.Int.Input(
                    "right", default=0, min=0, max=MAX_RESOLUTION, step=1,
                    tooltip="Pixels to add to the right edge.",
                ),
                io.Int.Input(
                    "bottom", default=0, min=0, max=MAX_RESOLUTION, step=1,
                    tooltip="Pixels to add to the bottom edge.",
                ),
            ],
            outputs=[
                io.Image.Output(
                    id="image_original",
                    display_name="image (original)",
                    tooltip="The image exactly as it came in, unpadded.",
                ),
                io.Image.Output(
                    id="image_padded",
                    display_name="image (padded)",
                    tooltip="The image on the enlarged canvas, with the new area filled.",
                ),
                io.Mask.Output(
                    id="mask",
                    tooltip="White over the new area, black over the original image, with "
                            "the feathered ramp in between.",
                ),
                io.Int.Output(id="width", tooltip="Width of the padded image."),
                io.Int.Output(id="height", tooltip="Height of the padded image."),
            ],
        )

    @classmethod
    def execute(cls, image, step, fill, feathering, left, top, right, bottom) -> io.NodeOutput:
        d1, d2, d3, d4 = image.size()

        left, top, right, bottom = resolve_padding(left, top, right, bottom, step)

        new_image = _fill_canvas(image, left, top, right, bottom, fill)
        new_image[:, top:top + d2, left:left + d3, :] = image

        mask = torch.ones(
            (d2 + top + bottom, d3 + left + right),
            dtype=torch.float32,
            device=image.device,
        )
        mask[top:top + d2, left:left + d3] = _feather_mask(
            d2, d3, left, top, right, bottom, feathering, image.device
        )

        new_w, new_h = d3 + left + right, d2 + top + bottom

        # The work above runs on whatever device the image arrived on, but IMAGE and
        # MASK are expected to travel on the CPU, so hand every tensor back on the CPU.
        # Otherwise a GPU image in gives GPU outputs, which then refuse to combine with
        # the CPU tensors other nodes produce. .cpu() is a no-op if it is already there.
        return io.NodeOutput(
            image.cpu(),
            new_image.cpu(),
            mask.unsqueeze(0).cpu(),
            new_w,
            new_h,
            # Read by web/js/image_pad_for_outpaint.js: "src" is the size of the incoming
            # image, used to draw the before -> after line on the node itself.
            ui={
                "text": [
                    f"{d3} x {d2}  ->  {new_w} x {new_h}",
                    f"L {left}   T {top}   R {right}   B {bottom}",
                ],
                "src": [d3, d2],
            },
        )
