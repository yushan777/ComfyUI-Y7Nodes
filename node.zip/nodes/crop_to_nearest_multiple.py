import torch

from comfy_api.latest import io


class Y7Nodes_CropToNearestMultiple(io.ComfyNode):
    """
    A node to crop images to align dimensions with the nearest multiple of a specified value
    """
    
    @classmethod
    def define_schema(cls):
        return io.Schema(
            node_id="Y7Nodes_CropToNearestMultiple",
            display_name="Y7 Crop to Nearest Multiple",
            category="Y7Nodes",
            description="Crop an image so its dimensions land on the nearest multiple of a value.",
            # Required to display UI data (dimensions) on the node
            is_output_node=True,
            inputs=[
                io.Image.Input("image"),
                io.Int.Input(
                    "multiple", default=16, min=1, max=1024, step=1,
                    tooltip="Image dimensions must be multiples of this value",
                ),
                io.Combo.Input(
                    "h_crop", options=["center", "left", "right", "none"], default="center",
                    tooltip="Horizontal crop position: where to keep content when width needs adjustment (none = no cropping)",
                ),
                io.Combo.Input(
                    "v_crop", options=["center", "top", "bottom", "none"], default="center",
                    tooltip="Vertical crop position: where to keep content when height needs adjustment (none = no cropping)",
                ),
            ],
            outputs=[
                io.Image.Output(display_name="crop_preview"),
                io.Image.Output(display_name="cropped_image"),
                io.String.Output(display_name="info"),
            ],
        )

    @classmethod
    def execute(cls, image, multiple, h_crop, v_crop) -> io.NodeOutput:
        """
        Check image dimensions and process accordingly
        """
        # Get image dimensions
        # In ComfyUI, images are typically in shape: [batch, height, width, channels]
        height = image.shape[1]
        width = image.shape[2]
        
        # Check if dimensions are even multiples of multiple
        width_is_multiple = (width % multiple) == 0
        height_is_multiple = (height % multiple) == 0
        
        # Start with original image
        output_image = image
        # Create preview with red overlay for crop areas
        crop_preview = image.clone()
        
        if width_is_multiple and height_is_multiple:
            info = f"✓ Dimensions are valid: {width}x{height} (multiple of {multiple}). No cropping necessary."
        else:
            # Calculate target dimensions (nearest multiples down)
            target_width = (width // multiple) * multiple
            target_height = (height // multiple) * multiple
            
            suggestions = []
            if not width_is_multiple:
                suggestions.append(f"Width {width} → {target_width}")
            if not height_is_multiple:
                suggestions.append(f"Height {height} → {target_height}")
            
            # Determine if cropping should be performed
            should_crop = (h_crop != "none" and not width_is_multiple) or \
                         (v_crop != "none" and not height_is_multiple)
            
            if should_crop:
                # Calculate crop offsets based on separate horizontal and vertical settings
                width_diff = width - target_width
                height_diff = height - target_height
                
                # Determine horizontal crop position
                # Note: When using "center" with odd-numbered differences, integer division (//) rounds down
                # Example: width=721, target=720, diff=1 -> left=0 (removes 1px from right only)
                # Example: width=723, target=720, diff=3 -> left=1 (removes 1px left, 2px right)
                # This is standard behavior in image processing - the slight bias is minimal (max 1px difference)
                if not width_is_multiple and h_crop != "none":
                    if h_crop == "center":
                        left = width_diff // 2
                    elif h_crop == "left":
                        left = 0
                    elif h_crop == "right":
                        left = width_diff
                else:
                    left = 0  # No horizontal cropping needed
                
                # Determine vertical crop position
                # Same rounding behavior applies to vertical cropping
                if not height_is_multiple and v_crop != "none":
                    if v_crop == "center":
                        top = height_diff // 2
                    elif v_crop == "top":
                        top = 0
                    elif v_crop == "bottom":
                        top = height_diff
                else:
                    top = 0  # No vertical cropping needed
                
                right = left + target_width
                bottom = top + target_height
                
                # Create crop preview with red overlay on areas to be cropped
                # Apply semi-transparent red overlay to cropped areas
                red_overlay = torch.tensor([1.0, 0.0, 0.0], device=image.device, dtype=image.dtype)
                alpha = 0.5  # Semi-transparent
                
                # Apply red to top area
                if top > 0:
                    crop_preview[:, :top, :, :] = crop_preview[:, :top, :, :] * (1 - alpha) + red_overlay * alpha
                
                # Apply red to bottom area
                if bottom < height:
                    crop_preview[:, bottom:, :, :] = crop_preview[:, bottom:, :, :] * (1 - alpha) + red_overlay * alpha
                
                # Apply red to left area (within the vertical crop bounds)
                if left > 0:
                    crop_preview[:, top:bottom, :left, :] = crop_preview[:, top:bottom, :left, :] * (1 - alpha) + red_overlay * alpha
                
                # Apply red to right area (within the vertical crop bounds)
                if right < width:
                    crop_preview[:, top:bottom, right:, :] = crop_preview[:, top:bottom, right:, :] * (1 - alpha) + red_overlay * alpha
                
                # Crop the image
                output_image = image[:, top:bottom, left:right, :]
                
                crop_info = []
                if not width_is_multiple and h_crop != "none":
                    crop_info.append(f"horizontal: {h_crop}")
                if not height_is_multiple and v_crop != "none":
                    crop_info.append(f"vertical: {v_crop}")
                
                info = f"✓ Image cropped from {width}x{height} to {target_width}x{target_height} ({', '.join(crop_info)})"
            else:
                info = f"✗ Dimensions not a multiple of {multiple}: {width}x{height}\n" + "\n".join(suggestions) + "\nSet h_crop/v_crop to enable automatic cropping"
        
        print(info)
        
        # Get final dimensions for UI display
        final_height = output_image.shape[1]
        final_width = output_image.shape[2]
        
        return io.NodeOutput(crop_preview, output_image, info, ui={"text": [f"{final_width} x {final_height}"]})
